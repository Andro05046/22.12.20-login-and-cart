import React, { Component } from 'react';
import { createDrawerNavigator} from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import Home from './screens/Home';
import Amezonpay from './screens/Amezonpay';
import Todaysdeals from './screens/Todaysdeals';
import Shopbycatogary from './screens/Shopbycatogary';
import Cart from './screens/Cart';
import Login from './screens/Login';
const CustomDrawerContentComponent = props => {
  return (
    <Container>
      <Header style={{backgroundColor: '#3a455c', height: 90}}></Header>
    </Container>
  );
};

const Drawer = createDrawerNavigator();
class App extends Component {

  render() {
    return (
      <NavigationContainer>
      <Drawer.Navigator  initialRouteName="Home"   drawerStyle={{
    backgroundColor: '#fff'
  }}   drawerContentOptions={{
    activeTintColor: 'black',
    activeBackgroundColor:'#fff',
    itemStyle: { marginVertical:5 },
  }}>
        <Drawer.Screen  name="Home" component={Home} />
        <Drawer.Screen name="Amezonpay" component={Amezonpay} />
        <Drawer.Screen name="Todaysdeals" component={Todaysdeals} />
        <Drawer.Screen name="Cart" component={Cart} />
        <Drawer.Screen name="Login" component={Login} />
        <Drawer.Screen name="Shopbycatogary" component={Shopbycatogary} />
      </Drawer.Navigator>
    </NavigationContainer>
    );
  }
}


export default App;
